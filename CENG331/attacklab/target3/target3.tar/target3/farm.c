/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_403()
{
    return 3352987976U;
}

void setval_480(unsigned *p)
{
    *p = 4039348315U;
}

unsigned getval_423()
{
    return 3284283720U;
}

void setval_394(unsigned *p)
{
    *p = 2428645704U;
}

unsigned addval_249(unsigned x)
{
    return x + 3465103411U;
}

unsigned getval_240()
{
    return 3347662934U;
}

unsigned getval_126()
{
    return 3251079496U;
}

unsigned getval_130()
{
    return 3285748040U;
}

unsigned addval_343(unsigned x)
{
    return x + 3465101397U;
}

unsigned addval_444(unsigned x)
{
    return x + 3285879112U;
}

unsigned getval_370()
{
    return 2425393179U;
}

unsigned getval_201()
{
    return 2463795528U;
}

unsigned addval_145(unsigned x)
{
    return x + 3285092680U;
}

unsigned addval_327(unsigned x)
{
    return x + 3285879112U;
}

unsigned getval_248()
{
    return 2428995912U;
}

unsigned addval_235(unsigned x)
{
    return x + 3507046594U;
}

unsigned getval_389()
{
    return 666983185U;
}

unsigned addval_285(unsigned x)
{
    return x + 2497218888U;
}

unsigned addval_138(unsigned x)
{
    return x + 3285289288U;
}

void setval_137(unsigned *p)
{
    *p = 3348711631U;
}

unsigned addval_484(unsigned x)
{
    return x + 3284275528U;
}

unsigned addval_387(unsigned x)
{
    return x + 2429651272U;
}

unsigned getval_468()
{
    return 3285748040U;
}

unsigned addval_148(unsigned x)
{
    return x + 3250729288U;
}

unsigned addval_410(unsigned x)
{
    return x + 3277541756U;
}

unsigned addval_115(unsigned x)
{
    return x + 3465111786U;
}

unsigned addval_390(unsigned x)
{
    return x + 2463205704U;
}

unsigned getval_447()
{
    return 3632879742U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
